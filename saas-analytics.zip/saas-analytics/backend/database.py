import os
from contextlib import contextmanager
import psycopg2
from psycopg2.extras import RealDictCursor

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://postgres:postgres@localhost:5432/saas_analytics"
)


def get_connection():
    return psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor)


@contextmanager
def tenant_db(tenant_id: str):
    """
    Opens a DB connection and sets the Postgres session variable
    'app.current_tenant' to the requesting user's tenant_id.

    This is what makes the Row-Level Security policies in schema.sql
    actually work: every query run inside this context is automatically
    filtered to only that tenant's rows by Postgres itself.
    """
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            # set_config(..., true) scopes this to the current transaction only
            cur.execute("SELECT set_config('app.current_tenant', %s, true)", (tenant_id,))
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
