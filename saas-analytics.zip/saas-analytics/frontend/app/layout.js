export const metadata = {
  title: "SaaS Analytics",
  description: "AI-powered KPI analytics platform",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
