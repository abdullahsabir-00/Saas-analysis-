const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export function getToken() {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem("token");
}

export function setToken(token) {
  window.localStorage.setItem("token", token);
}

async function request(path, options = {}) {
  const token = getToken();
  const headers = {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || `Request failed: ${res.status}`);
  }
  return res.json();
}

export async function signup(tenantName, email, password) {
  const data = await request("/auth/signup", {
    method: "POST",
    body: JSON.stringify({ tenant_name: tenantName, email, password }),
  });
  setToken(data.access_token);
  return data;
}

export async function login(email, password) {
  // FastAPI's OAuth2PasswordRequestForm expects form-encoded data, not JSON
  const body = new URLSearchParams();
  body.append("username", email);
  body.append("password", password);

  const res = await fetch(`${API_BASE}/auth/login`, { method: "POST", body });
  if (!res.ok) throw new Error("Invalid email or password");
  const data = await res.json();
  setToken(data.access_token);
  return data;
}

export function addMetric(metricName, metricValue) {
  return request("/metrics", {
    method: "POST",
    body: JSON.stringify({ metric_name: metricName, metric_value: metricValue }),
  });
}

export function listMetrics() {
  return request("/metrics");
}

export function generateSummary() {
  return request("/summary/generate", { method: "POST" });
}
