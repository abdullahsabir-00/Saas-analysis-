"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { getToken } from "./api";

export default function Home() {
  const router = useRouter();
  useEffect(() => {
    router.push(getToken() ? "/dashboard" : "/login");
  }, []);
  return null;
}
