"use client";
import { useEffect, useState } from "react";
import { addMetric, listMetrics, generateSummary, getToken } from "../api";
import { useRouter } from "next/navigation";

export default function Dashboard() {
  const router = useRouter();
  const [metrics, setMetrics] = useState([]);
  const [name, setName] = useState("");
  const [value, setValue] = useState("");
  const [summary, setSummary] = useState(null);
  const [loadingSummary, setLoadingSummary] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!getToken()) {
      router.push("/login");
      return;
    }
    refreshMetrics();
  }, []);

  async function refreshMetrics() {
    try {
      const data = await listMetrics();
      setMetrics(data);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleAddMetric(e) {
    e.preventDefault();
    try {
      await addMetric(name, parseFloat(value));
      setName("");
      setValue("");
      refreshMetrics();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleGenerateSummary() {
    setLoadingSummary(true);
    setError("");
    try {
      const data = await generateSummary();
      setSummary(data.summary);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoadingSummary(false);
    }
  }

  return (
    <main style={{ maxWidth: 700, margin: "40px auto", fontFamily: "sans-serif" }}>
      <h1>Analytics Dashboard</h1>

      <section style={{ marginBottom: 32 }}>
        <h2>Add a metric</h2>
        <form onSubmit={handleAddMetric} style={{ display: "flex", gap: 8 }}>
          <input placeholder="Metric name (e.g. monthly_revenue)" value={name}
                 onChange={(e) => setName(e.target.value)} required />
          <input placeholder="Value" type="number" value={value}
                 onChange={(e) => setValue(e.target.value)} required />
          <button type="submit">Add</button>
        </form>
      </section>

      <section style={{ marginBottom: 32 }}>
        <h2>Your metrics</h2>
        {metrics.length === 0 ? (
          <p>No metrics yet — add one above.</p>
        ) : (
          <ul>
            {metrics.map((m) => (
              <li key={m.id}>
                {m.metric_name}: {m.metric_value} ({new Date(m.recorded_at).toLocaleString()})
              </li>
            ))}
          </ul>
        )}
      </section>

      <section>
        <h2>AI KPI Summary</h2>
        <button onClick={handleGenerateSummary} disabled={loadingSummary}>
          {loadingSummary ? "Generating..." : "Generate Summary"}
        </button>
        {summary && <p style={{ marginTop: 12, padding: 12, background: "#f5f5f5" }}>{summary}</p>}
      </section>

      {error && <p style={{ color: "red" }}>{error}</p>}
    </main>
  );
}
