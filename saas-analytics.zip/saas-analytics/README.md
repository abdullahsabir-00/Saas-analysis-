# AI-Powered SaaS Analytics Platform (Core Build)

A working multi-tenant analytics app: companies sign up, log KPI metrics,
and generate AI-written executive summaries from their data.

## Architecture
- **Backend:** FastAPI + PostgreSQL, JWT auth, Row-Level Security for
  tenant isolation, GPT-4o for summary generation.
- **Frontend:** Next.js (App Router), plain fetch calls to the API.

## How multi-tenancy works
Every tenant-owned table (`users`, `metrics`, `ai_summaries`) has a
`tenant_id` column and a Postgres RLS policy. On every authenticated
request, the backend sets a session variable (`app.current_tenant`)
to the caller's tenant ID (decoded from their JWT). Postgres then
transparently filters every query to that tenant — enforced at the
database layer, not just app code.

## Setup

### 1. Database
```bash
createdb saas_analytics
psql saas_analytics -f backend/schema.sql
```

### 2. Backend
```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
export DATABASE_URL="postgresql://postgres:postgres@localhost:5432/saas_analytics"
export JWT_SECRET="change-me"
export OPENAI_API_KEY="sk-..."
uvicorn main:app --reload
```

### 3. Frontend
```bash
cd frontend
npm install
npm run dev
```

Visit `http://localhost:3000` — sign up as a new company, add a few
metrics, then click "Generate Summary" to see GPT-4 summarize them.

## What's real vs. what's simplified from the CV description
This build has: working auth, real RLS-enforced multi-tenancy, and a
real GPT-4 integration. It does **not** yet have: Stripe billing,
Docker/AWS deployment, or load-tested concurrency numbers — those are
the next additions once this core is solid. Be upfront about this
distinction if asked directly.
